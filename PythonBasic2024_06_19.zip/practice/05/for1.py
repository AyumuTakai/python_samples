score = [64, 90, 78, 82]

print(s)
