score_eng = int(input('英語の点数を入力して下さい：'))
score_math = int(input('数学の点数を入力して下しい：'))

print('合格です')

print('不合格です')
