number = int(input('テストの点数を入力して下さい：'))

print('優')

print('良')

print('可')

print('不可')