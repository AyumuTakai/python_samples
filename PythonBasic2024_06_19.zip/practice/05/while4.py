i = 0
while i < 3:
    i += 1
    score = int(input('点数を入力して下さい：'))
    if score >= 60:
        print('合格です')

    else:
        print('不合格です')
    
    score2 = int(input('追試点数を入力して下さい：'))
    if score2 >= 60:
        print('追試合格です')
    else:
        print('追試不合格です')
