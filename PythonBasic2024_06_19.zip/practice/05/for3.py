
print(i)
