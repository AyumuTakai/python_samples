rainy_percent = int(input('降水確率を入力して下さい：'))

print('傘を必ずもって行きましょう')

print('傘はあった方がいいかもしれません')

print('傘はいらないでしょう')