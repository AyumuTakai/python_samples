month = int(input('月を入力して下さい：'))

print('正しい月です')

print('正しくない月です')