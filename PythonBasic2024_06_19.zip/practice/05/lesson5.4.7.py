scores = []

print('最高得点は{0}です'.format(scores[4]))