number = int(input('整数を入力して下さい：'))
if number >= 0:
    print('正の値です')

    print('偶数です')

    print('奇数です')
else:
    print('負の値です')