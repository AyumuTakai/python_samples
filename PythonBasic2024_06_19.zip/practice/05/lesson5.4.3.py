
print('1から10までの合計は{0}です'.format(sum))
