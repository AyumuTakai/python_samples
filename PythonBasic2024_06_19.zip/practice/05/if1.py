has_error = True

print('残念')
print('エラーがあります')

print('正常です')
