a = []

print('True')

print('False')