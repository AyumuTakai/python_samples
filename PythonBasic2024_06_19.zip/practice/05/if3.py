number = int(input('整数を入力して下さい：'))

print('マイナスの値です')

print('偶数です')