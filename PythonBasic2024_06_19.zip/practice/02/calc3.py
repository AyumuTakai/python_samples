print(1 + 2)
print()
print()
