print('170cm')
print('60kg')
print('BMIは…')

print(60 / (1.70 * 1.70))
