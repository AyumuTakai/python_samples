a = 1
b = 2
# aとbを入れ替える


# 出力
print(a)
print(b)
