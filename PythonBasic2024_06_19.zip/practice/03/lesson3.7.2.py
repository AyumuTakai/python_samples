input('縦の長さ（m）')
input('横の長さ（m）')
print('面積は', '平方メートル')
