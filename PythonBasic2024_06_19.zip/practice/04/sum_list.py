score = [64, 90, 78, 82]




print('合計は{0}です'.format(sum_score)) # 合計を表示
