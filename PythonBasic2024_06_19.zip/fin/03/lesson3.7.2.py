heigth = float(input('縦の長さ（m）'))
width = float(input('横の長さ（m）'))
print('面積は', heigth * width, '平方メートル')