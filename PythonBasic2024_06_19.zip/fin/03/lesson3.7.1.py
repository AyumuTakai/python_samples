a = 1
b = 2
# aとbを入れ替える
c = a
a = b
b = c

# pythonでは以下の書き方も可能
# a, b = b, a

# 出力
print(a)
print(b)