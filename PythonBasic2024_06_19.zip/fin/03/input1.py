name = input('名前を入力して下さい：')
print('こんにちは{n}さん'.format(n=name))
