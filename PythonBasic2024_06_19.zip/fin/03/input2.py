name = input('名前を入力して下さい：')
tall = input('身長（cm）を入力して下さい：')
tall = int(tall) / 100
print('こんにちは' + name + 'さん')
print('あなたの身長は' + str(tall) + '（m）です')
