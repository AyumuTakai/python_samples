# print('170cm') # 身長
# print('60kg') # 体重
print('BMIは…')
# BMI計算：体重 kg ÷ (身長 m × 身長 m)
print(60 / (1.70 * 1.70))