scores = []
for i in range(1, 6):
    score = int(input('{0}番目の点数：'.format(i)))
    scores.append(score)
scores.sort()
print('最高得点は{0}です'.format(scores[4]))