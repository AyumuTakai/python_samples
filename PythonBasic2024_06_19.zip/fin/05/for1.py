score = [64, 90, 78, 82]
for s in score:
    print(s)
