sum = 0
for i in range(1, 11):
    sum += i
print('1から10までの合計は{0}です'.format(sum))
