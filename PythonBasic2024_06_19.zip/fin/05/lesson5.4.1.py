month = int(input('月を入力して下さい：'))
if 1 <= month <= 12:
    print('正しい月です')
else:
    print('正しくない月です')