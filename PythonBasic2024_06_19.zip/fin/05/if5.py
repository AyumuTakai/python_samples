score = 50
if score >= 60:
    pass
else:
    print('不合格です')