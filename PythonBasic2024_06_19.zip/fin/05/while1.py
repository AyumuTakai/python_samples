i = 0 # カウンタ変数を0で初期化
while i < 5:
    print(str(i) + '：Pythonの世界へようこそ')
    i += 1
