number = int(input('整数を入力して下さい：'))
if number < 0:
    print('マイナスの値です')
if number % 2 == 0:
    print('偶数です')