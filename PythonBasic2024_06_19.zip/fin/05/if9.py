a = []
if  a:
    print('True')
else:
    print('False')