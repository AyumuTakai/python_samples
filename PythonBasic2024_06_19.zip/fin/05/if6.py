score_eng = int(input('英語の点数を入力して下さい：'))
score_math = int(input('数学の点数を入力して下しい：'))
if score_eng >= 80 and score_math >= 70:
    print('合格です')
else:
    print('不合格です')
