i = 0
while i < 3:
    i += 1
    score = int(input('点数を入力して下さい：'))
    if score >= 60:
        print('合格です')
        break
    else:
        print('不合格です')
else:
    print('全て不合格でした')
