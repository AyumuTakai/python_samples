score = [64, 90, 78, 82]
for s in score:
    # 60点未満（不合格）の点数があった場合は中断する
    if s < 60:
        break
else:
    print('不合格の点数はありませんでした')
