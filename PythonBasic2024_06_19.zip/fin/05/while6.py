score = [64, 90, 78, 82]
i = 0
while i < len(score):
    print(score[i])
    i += 1
