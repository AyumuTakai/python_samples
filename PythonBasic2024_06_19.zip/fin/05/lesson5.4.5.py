num_list = [7, 12, 37, 24, 2, 92, 51]
for i in num_list:
    print(i)