number = int(input('テストの点数を入力して下さい：'))
if number >= 90:
    print('優')
elif number >= 80:
    print('良')
elif number >= 60:
    print('可')
else:
    print('不可')