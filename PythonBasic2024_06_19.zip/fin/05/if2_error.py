has_error = True
if has_error:
  print('残念')
    print('エラーがあります')
else:
    print('正常です')
