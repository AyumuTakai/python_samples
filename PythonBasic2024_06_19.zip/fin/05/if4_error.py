score = 50
if score >= 60:
else:
    print('不合格です')