score = [64, 90, 78, 82]
sum_score = 0
for s in score:
    print(s) # 要素の値を表示
    sum_score += s
print('点数の合計は{0}です'.format(sum_score))