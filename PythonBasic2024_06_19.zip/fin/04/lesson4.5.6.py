week_day_set1 = {'月', '火', '水', '木', '金'}
week_day_set2 = {'月', '土', '日'}
print(week_day_set1 & week_day_set2)