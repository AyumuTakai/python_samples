week_day_list = ['月', '火', '水', '木', '金', '土']
print(week_day_list)