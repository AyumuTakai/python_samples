week_day_list = ['月', '火', '水', '木', '金', '土', '日']
print(week_day_list[0:5])