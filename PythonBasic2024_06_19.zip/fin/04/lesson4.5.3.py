week_day_list = ['月', '火', '水', '木', '金', '土']
week_day_list.append('日')
print(week_day_list)