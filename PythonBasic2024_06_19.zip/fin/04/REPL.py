"""
第3章のREPLでの例題

(行頭の#%%というコメントはVsCodeのJupyter拡張機能のためのものです)

"""

# %% p.52 飲み会参加者
name1 = '鈴木一郎'
name2 = '高橋二郎'
name3 = '田中三郎'


# %% p.52 テストの点数
score1 = 64
score2 = 90
score3 = 78
score4 = 82

# %% p.53 リストの作成
score = [64, 90, 78, 82]
score

# %% p.53 リスト途中での改行
name = [
    '鈴木一郎',
    '高橋二郎',
    '田中三郎'
]
name

# %% p.53 空のリスト
list1 = []
list1

# %% p.53 空のリスト
list2 = list()
list2

# %% p.53 リストから値の取得
score = [64, 90, 78, 82]
score[0]

# %% p.53 リストから値の取得
score[3]

# %% p.53 存在しないインデックス
score[4]

# %% p.53 ミュータブルなリスト
score = [64, 90, 78, 82]
score[1] = 100
score

# %% p.55 スライス
number = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
number[1:4]

# %% p.55 スライス
number[3:] # 末尾の省略

# %% p.55 スライス
number[:4] # 先頭の省略

# %% p.55 スライス
number[2:7:2] # 2個飛ばしで取得

# %% p.55 スライス
number[::3] # リストの開始から終了まで3飛しで取得

# %% p.55 スライス
number[-2] # 最後から2個目の値を取得

# %% p.55 スライス
number[-4:-1] # 最後から4個目から最後から1個目までを取得

# %% p.55 要素数の確認
score = [64, 90, 78, 82]
len(score)

# %% p.55 要素数の確認
name = ['鈴木一郎', '高橋二郎', '田中三郎']
len(name)

# %% p.56 要素の追加
name = ['鈴木一郎', '高橋二郎', '田中三郎']
name.append('佐藤四郎')
name

# %% p.57 リストの連結
list1 = [1, 2, 3]
list2 = [4, 5, 6]
list3 = list1 + list2
list3

# %% p.57 リストの連結
list3 += [7, 8, 9]
list3

# %% p.57 inによる有無の確認
name = ['鈴木一郎', '高橋二郎', '田中三郎']
'田中三郎' in name

# %% p.57 inによる有無の確認
'松本四郎' in name

# %% p.58 リストのリスト
score_a = [100, 80, 90]
score_b = [30, 45, 20]
score_list = [score_a, score_b]
score_list

# %% p.58 リストのリスト
score_list[0][2]

# %% p.58 リストのリスト
list_a = [1, '鈴木一郎', True]
list_b = [2, '高橋二郎']
list_c = [list_a, list_b]
list_c

# %% p.59 sorted関数
sort_list = ['ccc', 'aaa', 'bbb']
sorted_list = sorted(sort_list)
sorted_list

# %% p.59 sorted関数
sort_list

# %% p.59 sortメソッド
sort_list = ['ccc', 'aaa', 'bbb']
sort_list.sort()
sort_list

# %% p.60 リストの更新
score1 = [64, 90, 78, 82]
score2 = score1
score1[1] = 'NG'
score1

# %% p.60 リストの更新
score2

# %% p.61 リストのコピー
score1 = [64, 90, 78, 82]
score3 = score1.copy()
score3[1] = 'NG'
score3

#%% p.61 リストのコピー
score1

# %% p.61 リストのコピー
score1 = [64, 90, 78, 82]
score4 = list(score1) # リスト関数によるオブジェクトの新規生成
score4

# %% p.61 リストのコピー
score5 = score1[:]
score5

# %% p.62 タプルの作成
score_t = (64, 100, 78, 82) # タプルの作成
score_t

# %% p.62 タプルの作成
score_t[2] # 要素の取得

# %% p.62 # タプルの要素の更新
score_t[2] = 100

# %% p.62 空のタプルを作成
tuple_none = ()
tuple_none

# %% p.62 要素が1個のタプル
tuple1 = (20)
tuple1

# %% p.62 要素が1個のタプル
tuple2 = (20,)
tuple2


# %% p.63 丸括弧の省略
tuple2 = 20,
tuple2

# %% p.63 丸括弧の省略
score_t = 64, 100, 78, 82
score_t

# %% p.63 タプルとリストの変換
score_l = [1, 2, 3] # リストの作成
score_t = tuple(score_l) # リストをタプルに変換
score_t

# %% p.63 タプルとリストの変換
score_l2 = list(score_t) # タプルをリストに変換
score_l2

# %% p.63 複数の変数への代入
tuple3 = (1, 2, 3)
a,b,c = tuple3
a

# %% p.63 複数の変数への代入
b

# %% p.63 複数の変数への代入
c

# %% p.65 集合型の作成
set1 = {1, 2, 3}
set1

# %% p.65 集合型の作成
set2 = {1, 2, 2} # 重複する要素は保持されない
set2

# %% p.66 集合型の演算
name_s1 = {'鈴木', '高橋', '田中'}
name_s2 = {'鈴木', '斉藤'}
name_s3 = {'鈴木', '田中'}
'鈴木' in name_s1 # '鈴木'を含んでいればTrue

# %% p.66 集合型の演算
'斉藤' in name_s1 # '斉藤'を含んでいないのでFalse

# %% p.66 集合型の演算
name_s1 >= name_s3 # name_s3がname_s1に全て含まれていればTrue

# %% p.66 集合型の演算
name_s1 & name_s2 # AND演算

# %% p.66 集合型の演算
name_s1 | name_s2 # OR演算

# %% p.66 集合型の演算
name_s1 ^ name_s2 # XOR演算

# %% p.66 集合型の演算
name_s1 - name_s2 # 減算

# %% p.67 辞書型の作成
score_d = {'english':60, 'mathematics':100, 'science': 78, 'society': 82}
score_d

# %% p.66 空の辞書の作成
dict_none = {}
dict_none

# %% p.68 辞書型のデータの参照
score_d = {'english':60, 'mathematics':100, 'science': 78, 'society': 82}
score_d['science'] # キーを指定しての参照


# %% p.68 辞書型のデータの更新
score_d['science'] = 50 # キーを指定しての更新
score_d


# %% p.68 キーの存在確認
score_d = {'english':60, 'mathematics':100, 'science': 78, 'society': 82}
'english' in score_d

# %% p.68 キーの存在確認
'engrish' in score_d

# %% dict関数による変換
score_l = [['english', 60],['mathematics', 100]]
score_l

# %% dict関数による変換
score_d = dict(score_l)
score_d

